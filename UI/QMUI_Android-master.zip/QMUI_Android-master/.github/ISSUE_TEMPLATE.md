### 运行环境 ###

- [x] 设备型号：如：`Nexus 6`
- [x] 设备系统版本：如 `Android 5.0`
- [x] Gradle 版本：如 `2.3.0`
- [x] QMUI Android 版本：`1.x.x`

### 具体问题描述 ###

#### 问题截图 ####

#### Layout Inspector 文件([如何获取](https://github.com/QMUI/QMUI_Android/wiki/%E6%8F%90%E4%BE%9B-Layout-Inspector-%E6%96%87%E4%BB%B6)) ####

#### 异常日志（堆栈） ####
